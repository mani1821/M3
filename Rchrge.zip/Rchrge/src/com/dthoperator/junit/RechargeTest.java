package com.dthoperator.junit;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;


import com.dthoperator.bean.*;
import com.dthoperator.exception.*;
import com.dthoperator.service.*;
import com.dthoperator.ui.*;
public class RechargeTest {

	
	
	static RechargeDataValidator val=new RechargeDataValidator();
	
	@Test
	public void testID() throws RechargeException {

		Assert.assertEquals(true,val.validate_oper("airtel"));
		
	}
	
	
	@Test
	public void testPrice() throws RechargeException {

		Assert.assertEquals(true,val.validate_amount(896));
		
	}
	

	@Test
	public void testid() throws RechargeException {

		Assert.assertEquals(true,val.validate_id("9876543210"));
		
	}
	
	@Test
	public void testplan() throws RechargeException {

		Assert.assertEquals(true,val.validate_plan("monthly"));
		
	}
}
