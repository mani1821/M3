package com.dthoperator.bean;

public class RechargeDetails {

	long consumerNo;
	String rechargePlan;
	int amount;
	int transactionID;
	
	public RechargeDetails(String dthOperator,long consumerNo,String rechargePlan,int amount,int transactionID)
	{
		this.dthOperator=dthOperator;
		this.consumerNo=consumerNo;
		this.rechargePlan=rechargePlan;
		this.amount=amount;
		this.transactionID=transactionID;
	}
	String dthOperator;
    @Override
	public String toString() {
		return "RechargeDetails [dthOperator=" + dthOperator + ", consumerNo="
				+ consumerNo + ", rechargePlan=" + rechargePlan + ", amount="
				+ amount + ", transactionID=" + transactionID + "]";
	}


}
