package com.dthoperator.exception;
public class RechargeException extends Exception {
  public RechargeException(int a)
{
	System.out.println("Failed to recharge because of wrong selection of amount");
	return  ;
}
  public RechargeException(String a)
{
	System.out.println("Failed to recharge because of wrong selection of operator");
	return  ;
}
  public RechargeException(float a)
{
	System.out.println("Failed to recharge because of wrong selection of plan");
	return  ;
}
  public RechargeException(double a)
{
	System.out.println("Failed to recharge because of wrong selection of id");
	return  ;
}
}
