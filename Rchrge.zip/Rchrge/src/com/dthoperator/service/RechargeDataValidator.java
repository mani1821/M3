package com.dthoperator.service;

import java.util.regex.Pattern;

import com.dthoperator.exception.*;

public class RechargeDataValidator {
	
	
	
	public static boolean validate_oper(String oper) throws RechargeException
	{String pattern = "[A-Za-z]{3,10}";
	boolean a=oper.toLowerCase().equals("dishtv") ||oper.toLowerCase().equals("reliance")|| oper.toLowerCase().equals("tatasky")||oper.toLowerCase().equals("airtel");
	//System.out.println(a);
	if(Pattern.matches(pattern,oper) && a ){
		
		return true;
	}
	else
	{
		try{
		throw new RechargeException(oper);
		}
		catch(RechargeException e)
		{
			
		}
		finally{
			return false;
		}
	}
	}
	
	
	public static boolean validate_id(String id) throws RechargeException
	{String pattern = "[0-9]{10,10}";
	if(Pattern.matches(pattern,id)){
		return true;
	}
	else
	{
		double a=5;
		try{
			throw new RechargeException(a);
			}
			catch(RechargeException e)
			{
				
			}
			finally{
				return false;
			}
		
	}
	
}
	
	
	
	public static boolean validate_plan(String oper) throws RechargeException
	{
		String pattern = "[A-Za-z]{3,10}";
		boolean a=oper.toLowerCase().equals("monthly") ||oper.toLowerCase().equals("quaterly")|| oper.toLowerCase().equals("Half yearly")||oper.toLowerCase().equals("annual");
		if(Pattern.matches(pattern,oper)&& a){
			return true;
		}
		else
		{
			float b=5;
			try{
				throw new RechargeException(b);
				}
				catch(RechargeException e)
				{
					
				}
				finally{
					return false;
				}
			
		}
	}
	
	
	public static boolean validate_amount(int id) throws RechargeException
	{
		String price=Integer.toString(id);
		String pattern = "[0-9]{3,4}";
		if(Pattern.matches(pattern,price)){
			return true;
		}
		else
		{
			
			try{
				throw new RechargeException(id);
				}
				catch(RechargeException e)
				{
					
				}
				finally{
					return false;
				}
			
		}
	}
	
	
	
	
}