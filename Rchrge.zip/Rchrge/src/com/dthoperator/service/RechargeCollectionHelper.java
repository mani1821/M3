package com.dthoperator.service;
import java.util.*;

import com.dthoperator.bean.*;
public class RechargeCollectionHelper {
	static List<RechargeDetails> list = new ArrayList<RechargeDetails>();
	static int count=0;
	static{
		RechargeDetails obj=new RechargeDetails("Airtel",1234567890,"Monthly",335,986); 
		list.add(obj);
	}
	
	public static void adddetails(RechargeDetails obj)
	{
		list.add(obj);
		System.out.print("Successfull Recharge.");
	}
	
	public static void display_rec()
	{
		for(Object object: list)
			System.out.println(object);
	} 
	
}
