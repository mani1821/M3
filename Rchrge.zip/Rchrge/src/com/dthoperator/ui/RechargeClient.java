package com.dthoperator.ui;
import java.util.*;
import com.dthoperator.bean.*;
import com.dthoperator.service.*;
import com.dthoperator.exception.*;
public class RechargeClient {
	static Scanner cin=new Scanner(System.in);
	public static void main(String args[]) throws RechargeException
	{
		String choice;
		System.out.println("Welcome to Online DTH Recharge ");
		while(true)
		{
		System.out.println("1.Make Recharge");
		System.out.println("2.Display Details");
		System.out.println("3.Exit");
		choice=cin.next();
		switch(choice)
		{
		case "1":{
			adddetails();
			break;
		}
		case "2":{
			//display details
			RechargeCollectionHelper.display_rec();
			break;
		}
		case "3":{
			//Exit
			System.out.println("ThankYou");
			System.exit(0);
			break;
		}
		case "4":{
			System.out.println("Wrong option selected");
		}
		}
		
		}
		
	}
	public static void adddetails() throws RechargeException
	{
		int turn=2;
		while(turn!=0)
		{
			if(turn==1)
			{
				System.out.println("Enter details of tv in home");
			}
			else if(turn==2)
			{
				System.out.println("Enter details of tv in Office");
			}
		System.out.println("Select DTH Operator (Airtel / DishTV / Reliance / TATASky)");
		String opr=cin.next();
		if(!RechargeDataValidator.validate_oper(opr))
		{
			System.exit(0);
			
		}
		System.out.println("Enter consumerno ");
		String cid=cin.next();
		if(!RechargeDataValidator.validate_id(cid))
		{
			System.exit(0);
			
		}
		System.out.println("Select paln  Monthly / Quaterly / Half yearly / Annual");
		String plan=cin.next();
		if(!RechargeDataValidator.validate_plan(plan))
		{
			System.exit(0);
			
		}
		System.out.println("Enter price ");
		int amt=cin.nextInt();
		if(!RechargeDataValidator.validate_amount(amt))
		{
			System.exit(0);
			
		}
		
		
		
		
		
		Random randomGenerator = new Random();
		int txn_id = randomGenerator.nextInt(9999);
		long cno=Long.parseLong(cid);	
		
		
		RechargeDetails obj=new RechargeDetails(opr,cno,plan,amt,txn_id);
		RechargeCollectionHelper.adddetails(obj);
		System.out.println(" Transaction Id:<"+txn_id+">");
		turn--;
		}
		}

}
